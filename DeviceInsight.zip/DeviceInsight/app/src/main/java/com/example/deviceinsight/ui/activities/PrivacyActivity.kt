package com.example.deviceinsight.ui.activities

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.deviceinsight.R

class PrivacyActivity : AppCompatActivity() {

    private lateinit var txtPermissionStatus: TextView
    private lateinit var txtPermissionsList: TextView
    private lateinit var btnRequestPermissions: Button
    private lateinit var btnAppSettings: Button

    // Lista de permisos necesarios
    private val requiredPermissions = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.ACCESS_WIFI_STATE,
        Manifest.permission.ACCESS_NETWORK_STATE
    )

    // Nombres amigables para los permisos
    private val permissionDisplayNames = mapOf(
        Manifest.permission.ACCESS_FINE_LOCATION to "Ubicación precisa",
        Manifest.permission.ACCESS_COARSE_LOCATION to "Ubicación aproximada",
        Manifest.permission.READ_PHONE_STATE to "Estado del teléfono",
        Manifest.permission.ACCESS_WIFI_STATE to "Estado de Wi-Fi",
        Manifest.permission.ACCESS_NETWORK_STATE to "Estado de red"
    )

    // Descripciones de los permisos
    private val permissionDescriptions = mapOf(
        Manifest.permission.ACCESS_FINE_LOCATION to "Para obtener información precisa de redes Wi-Fi cercanas",
        Manifest.permission.ACCESS_COARSE_LOCATION to "Para detectar redes disponibles en tu área",
        Manifest.permission.READ_PHONE_STATE to "Para obtener información del operador móvil y tipo de red",
        Manifest.permission.ACCESS_WIFI_STATE to "Para monitorear el estado de conexión Wi-Fi",
        Manifest.permission.ACCESS_NETWORK_STATE to "Para verificar la conectividad general de red"
    )

    // Launcher para solicitar permisos
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Actualizar estado después de que el usuario responde
        updatePermissionStatus()

        // Mostrar resultado
        val grantedCount = permissions.count { it.value }
        val totalCount = permissions.size

        if (grantedCount == totalCount) {
            showMessage("¡Éxito!", "Todos los permisos han sido concedidos ✅")
        } else {
            showMessage("Permisos incompletos",
                "Concedidos: $grantedCount de $totalCount\n\n" +
                        "Algunas funciones pueden no estar disponibles.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_privacy)

        setupUI()
        updatePermissionStatus()
    }

    private fun setupUI() {
        txtPermissionStatus = findViewById(R.id.txtPermissionStatus)
        txtPermissionsList = findViewById(R.id.txtPermissionsList)
        btnRequestPermissions = findViewById(R.id.btnRequestPermissions)
        btnAppSettings = findViewById(R.id.btnAppSettings)

        // Botón para solicitar permisos
        btnRequestPermissions.setOnClickListener {
            requestMissingPermissions()
        }

        // Botón para abrir configuración de la app
        btnAppSettings.setOnClickListener {
            openAppSettings()
        }

        // Explicación de privacidad
        val txtPrivacyExplanation: TextView = findViewById(R.id.txtPrivacyExplanation)
        txtPrivacyExplanation.text = """
            🔒 Política de Privacidad
            
            Esta aplicación requiere ciertos permisos para funcionar correctamente:
            
            • Ubicación: Para detectar redes Wi-Fi cercanas y su intensidad de señal
            • Teléfono: Para identificar tu operador móvil y tipo de conexión
            • Red: Para monitorear el estado de tu conectividad
            
            📍 Tus datos están seguros:
            • Toda la información se procesa localmente en tu dispositivo
            • No recopilamos ni enviamos tus datos a servidores externos
            • Los sensores solo se activan cuando tú lo permites
            
            Los permisos son necesarios para proporcionarte información precisa sobre tu dispositivo y conexiones.
        """.trimIndent()
    }

    private fun updatePermissionStatus() {
        val grantedPermissions = mutableListOf<String>()
        val deniedPermissions = mutableListOf<String>()

        // Clasificar permisos
        requiredPermissions.forEach { permission ->
            val displayName = permissionDisplayNames[permission] ?: permission
            if (hasPermission(permission)) {
                grantedPermissions.add("✅ $displayName")
            } else {
                deniedPermissions.add("❌ $displayName")
            }
        }

        // Actualizar estado general
        val totalPermissions = requiredPermissions.size
        val grantedCount = grantedPermissions.size

        txtPermissionStatus.text = "Permisos: $grantedCount/$totalPermissions concedidos"

        // Actualizar lista detallada
        val allPermissions = (grantedPermissions + deniedPermissions).joinToString("\n")
        txtPermissionsList.text = allPermissions

        // Actualizar estado del botón
        btnRequestPermissions.isEnabled = deniedPermissions.isNotEmpty()
        btnRequestPermissions.text = if (deniedPermissions.isNotEmpty()) {
            "Solicitar Permisos Faltantes (${deniedPermissions.size})"
        } else {
            "Todos los Permisos Concedidos ✅"
        }
    }

    private fun requestMissingPermissions() {
        val missingPermissions = requiredPermissions.filter { !hasPermission(it) }.toTypedArray()

        if (missingPermissions.isNotEmpty()) {
            // Mostrar explicación antes de solicitar
            showPermissionExplanation(missingPermissions)
        } else {
            showMessage("Información", "Todos los permisos ya están concedidos ✅")
        }
    }

    private fun showPermissionExplanation(permissions: Array<String>) {
        val permissionNames = permissions.map {
            permissionDisplayNames[it] ?: it
        }.joinToString("\n• ")

        val permissionReasons = permissions.map {
            permissionDescriptions[it] ?: "Necesario para la funcionalidad de la aplicación"
        }.joinToString("\n\n")

        AlertDialog.Builder(this)
            .setTitle("¿Por qué necesitamos estos permisos?")
            .setMessage(
                "Para acceder a las siguientes funciones:\n\n" +
                        "• $permissionNames\n\n" +
                        "$permissionReasons\n\n" +
                        "¿Deseas conceder estos permisos ahora?"
            )
            .setPositiveButton("Sí, conceder") { dialog, which ->
                // Solicitar permisos
                requestPermissionLauncher.launch(permissions)
            }
            .setNegativeButton("Ahora no", null)
            .setNeutralButton("Más información") { dialog, which ->
                showDetailedExplanation(permissions)
            }
            .show()
    }

    private fun showDetailedExplanation(permissions: Array<String>) {
        val detailedText = permissions.joinToString("\n\n") { permission ->
            val name = permissionDisplayNames[permission] ?: permission
            val description = permissionDescriptions[permission] ?: "Permiso necesario para la funcionalidad completa de la aplicación."

            "🔹 $name:\n$description"
        }

        AlertDialog.Builder(this)
            .setTitle("Explicación Detallada de Permisos")
            .setMessage(detailedText)
            .setPositiveButton("Entendido, conceder") { dialog, which ->
                requestPermissionLauncher.launch(permissions)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun openAppSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
            }
            startActivity(intent)
        } catch (e: Exception) {
            showMessage("Error", "No se pudo abrir la configuración de la aplicación")
        }
    }

    private fun showMessage(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Aceptar", null)
            .show()
    }

    private fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    override fun onResume() {
        super.onResume()
        // Actualizar estado cuando la actividad se reanuda (por si el usuario cambió permisos en settings)
        updatePermissionStatus()
    }
}