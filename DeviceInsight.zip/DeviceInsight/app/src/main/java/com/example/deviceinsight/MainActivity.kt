package com.example.deviceinsight

import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.deviceinsight.ui.activities.ConnectivityActivity
import com.example.deviceinsight.ui.activities.PrivacyActivity
import java.util.Locale
class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var playButton: Button
    private lateinit var statusText: TextView
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val sensorButton: Button = findViewById(R.id.BTTNSensores)
        playButton = findViewById(R.id.BTTNPlay)
        statusText = findViewById(R.id.TVHola)

        // Inicializar Text-to-Speech
        tts = TextToSpeech(this, this)

        statusText.text = "Inicializando..."
        playButton.isEnabled = false

        // Botón Sensores
        sensorButton.setOnClickListener {
            val intent = Intent(this, Sensores::class.java)
            startActivity(intent)
        }

        // Botón Tócame
        playButton.setOnClickListener {
            if (ttsReady) {
                tts.speak("Puedo hablar con Text to Speech", TextToSpeech.QUEUE_FLUSH, null, "")
                statusText.text = "Reproduciendo: ¡Puedo hablar!"
            } else {
                Toast.makeText(this, "TTS no está listo aún", Toast.LENGTH_SHORT).show()
            }
        }

        // Buscar el botón de conectividad
        val connectivityButton: Button = findViewById(R.id.bttnConnectivity)

        // Configurar el click listener
        connectivityButton.setOnClickListener {
            val intent = Intent(this, ConnectivityActivity::class.java)
            startActivity(intent)
        }


        // Botón Privacidad
        val privacyButton: Button = findViewById(R.id.bttnPrivacy)
        privacyButton.setOnClickListener {
            val intent = Intent(this, PrivacyActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("es", "ES"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "Idioma español no soportado", Toast.LENGTH_SHORT).show()
                statusText.text = "Español no disponible"
            } else {
                ttsReady = true
                playButton.isEnabled = true
                statusText.text = "¡Listo! Toca el botón para hablar"
            }
        } else {
            Toast.makeText(this, "TTS falló en inicializar", Toast.LENGTH_SHORT).show()
            statusText.text = "Error en TTS"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tts.stop()
        tts.shutdown()
    }
}