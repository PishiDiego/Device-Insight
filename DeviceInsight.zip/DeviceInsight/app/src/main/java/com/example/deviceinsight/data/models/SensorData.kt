package com.example.deviceinsight.data.models

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SensorData(
    val sensorType: String,
    val values: FloatArray,
    val timestamp: Long = System.currentTimeMillis()
) {
    val formattedTime: String
        get() = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date(timestamp))

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as SensorData
        if (sensorType != other.sensorType) return false
        if (!values.contentEquals(other.values)) return false
        if (timestamp != other.timestamp) return false

        return true
    }

    override fun hashCode(): Int {
        var result = sensorType.hashCode()
        result = 31 * result + values.contentHashCode()
        result = 31 * result + timestamp.hashCode()
        return result
    }
}