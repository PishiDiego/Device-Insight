package com.example.deviceinsight.ui.activities

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Bundle
import android.telephony.TelephonyManager
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.deviceinsight.R

class ConnectivityActivity : AppCompatActivity() {

    private lateinit var txtConnectionStatus: TextView
    private lateinit var txtConnectionType: TextView
    private lateinit var txtWifiInfo: TextView
    private lateinit var txtCellularInfo: TextView
    private lateinit var txtPermissionStatus: TextView

    // Launcher para solicitar permisos de ubicación
    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            // Permiso concedido, actualizar información
            checkConnectivity()
            showMessage("Éxito", "Permiso de ubicación concedido. La información de Wi-Fi ahora está disponible.")
        } else {
            // Permiso denegado
            txtWifiInfo.text = "❌ Permiso de ubicación denegado. No se puede obtener información de redes Wi-Fi."
            updatePermissionStatus()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_connectivity)

        setupUI()
        checkConnectivity()
    }

    private fun setupUI() {
        txtConnectionStatus = findViewById(R.id.txtConnectionStatus)
        txtConnectionType = findViewById(R.id.txtConnectionType)
        txtWifiInfo = findViewById(R.id.txtWifiInfo)
        txtCellularInfo = findViewById(R.id.txtCellularInfo)
        txtPermissionStatus = findViewById(R.id.txtPermissionStatus)
    }

    private fun checkConnectivity() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork
        val capabilities = connectivityManager.getNetworkCapabilities(network)

        // Estado de conexión básico (no necesita permisos)
        val isConnected = capabilities != null &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)

        txtConnectionStatus.text = if (isConnected) "✅ Conectado a Internet" else "❌ Sin conexión a Internet"

        // Tipo de conexión (no necesita permisos)
        val connectionType = when {
            capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
            capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Datos Móviles"
            capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            else -> "Desconocido o Sin Conexión"
        }
        txtConnectionType.text = "Tipo de conexión: $connectionType"

        // Información de Wi-Fi (necesita permisos)
        checkWifiInfo(connectionType)

        // Información celular (necesita permisos)
        checkCellularInfo(connectionType)

        // Estado de permisos
        updatePermissionStatus()
    }

    private fun checkWifiInfo(connectionType: String) {
        if (connectionType == "Wi-Fi") {
            if (hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
                try {
                    val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    val wifiInfo = wifiManager.connectionInfo
                    val ssid = wifiInfo.ssid?.removeSurrounding("\"") ?: "Red Oculta"
                    val signalStrength = wifiInfo.rssi
                    val signalLevel = when {
                        signalStrength >= -50 -> "Excelente"
                        signalStrength >= -60 -> "Muy Bueno"
                        signalStrength >= -70 -> "Bueno"
                        signalStrength >= -80 -> "Regular"
                        else -> "Débil"
                    }

                    txtWifiInfo.text = """
                        📶 Información Wi-Fi:
                        • Red: $ssid
                        • Señal: $signalStrength dBm ($signalLevel)
                        • BSSID: ${wifiInfo.bssid ?: "No disponible"}
                    """.trimIndent()
                } catch (e: SecurityException) {
                    txtWifiInfo.text = "❌ Error de permisos al acceder a información Wi-Fi"
                }
            } else {
                txtWifiInfo.text = """
                    ℹ️ Conectado a Wi-Fi
                    • Se necesita permiso de ubicación para ver detalles de la red
                    • [Toca aquí para solicitar permiso]
                """.trimIndent()

                // Hacer el texto clickeable para solicitar permiso
                txtWifiInfo.setOnClickListener {
                    requestLocationPermissionForWifi()
                }
            }
        } else {
            txtWifiInfo.text = "📶 No conectado a Wi-Fi"
            txtWifiInfo.setOnClickListener(null)
        }
    }

    // ✅ CORREGIDO: Eliminar la clase duplicada y dejar solo el método
    private fun checkCellularInfo(connectionType: String) {
        try {
            val telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val operatorName = telephonyManager.networkOperatorName
            val networkType = getNetworkTypeName(telephonyManager.dataNetworkType)
            val simOperator = telephonyManager.simOperatorName

            // Verificar si tenemos permisos
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {

                txtCellularInfo.text = """
                    █ Información de Red Móvil:
                    · Operador: ${operatorName.takeIf { it.isNotEmpty() } ?: "Desconocido"}
                    · SIM: ${simOperator.takeIf { it.isNotEmpty() } ?: "No disponible"}
                    · Tipo de Red: $networkType
                """.trimIndent()

            } else {
                txtCellularInfo.text = """
                    █ Conectado a Datos Móviles
                    · Se necesita permiso de estado del teléfono para ver detalles
                    · Ve a Configuración > Aplicaciones > Device Insight > Permisos
                """.trimIndent()
            }
        } catch (e: SecurityException) {
            txtCellularInfo.text = "Error de permisos al acceder a información móvil"
        } catch (e: Exception) {
            txtCellularInfo.text = "Error al obtener información celular: ${e.message}"
        }
    }

    // Función auxiliar para obtener el nombre del tipo de red
    private fun getNetworkTypeName(networkType: Int): String {
        return when (networkType) {
            TelephonyManager.NETWORK_TYPE_GPRS -> "GPRS (2G)"
            TelephonyManager.NETWORK_TYPE_EDGE -> "EDGE (2G)"
            TelephonyManager.NETWORK_TYPE_UMTS -> "UMTS (3G)"
            TelephonyManager.NETWORK_TYPE_HSDPA -> "HSDPA (3.5G)"
            TelephonyManager.NETWORK_TYPE_HSUPA -> "HSUPA (3.5G)"
            TelephonyManager.NETWORK_TYPE_HSPA -> "HSPA (3.5G)"
            TelephonyManager.NETWORK_TYPE_LTE -> "LTE (4G)"
            TelephonyManager.NETWORK_TYPE_NR -> "5G NR"
            TelephonyManager.NETWORK_TYPE_CDMA -> "CDMA (2G)"
            TelephonyManager.NETWORK_TYPE_EVDO_0 -> "EV-DO Rev. 0 (3G)"
            else -> "Desconocido (Tipo: $networkType)"
        }
    }

    private fun requestLocationPermissionForWifi() {
        AlertDialog.Builder(this)
            .setTitle("Permiso de Ubicación Requerido")
            .setMessage("Para mostrar información detallada de redes Wi-Fi (nombre de red, intensidad de señal), necesitamos el permiso de ubicación.\n\nEste permiso NO se usa para rastrear tu ubicación, solo para acceder a información de redes Wi-Fi cercanas.")
            .setPositiveButton("Conceder Permiso") { dialog, which ->
                locationPermissionLauncher.launch(arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ))
            }
            .setNegativeButton("Ahora no", null)
            .show()
    }

    private fun updatePermissionStatus() {
        val missingPermissions = mutableListOf<String>()

        if (!hasPermission(Manifest.permission.ACCESS_NETWORK_STATE)) {
            missingPermissions.add("Estado de Red")
        }
        if (!hasPermission(Manifest.permission.ACCESS_WIFI_STATE)) {
            missingPermissions.add("Estado Wi-Fi")
        }
        if (!hasPermission(Manifest.permission.READ_PHONE_STATE)) {
            missingPermissions.add("Estado Teléfono")
        }
        if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
            missingPermissions.add("Ubicación (Wi-Fi)")
        }

        txtPermissionStatus.text = if (missingPermissions.isEmpty()) {
            "✅ Todos los permisos concedidos - Información completa disponible"
        } else {
            "⚠️ Funcionalidades limitadas - Permisos faltantes: ${missingPermissions.joinToString()}"
        }
    }

    private fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun showMessage(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Aceptar", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        // Actualizar información cuando la actividad se reanuda
        checkConnectivity()
    }
}