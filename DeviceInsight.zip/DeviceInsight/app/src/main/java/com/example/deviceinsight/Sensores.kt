package com.example.deviceinsight

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.deviceinsight.data.models.SensorData

class Sensores : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var lightSensor: Sensor? = null
    private var isMonitoring = true

    private lateinit var txtX: TextView
    private lateinit var txtY: TextView
    private lateinit var txtZ: TextView
    private lateinit var txtLight: TextView
    private lateinit var txtStatus: TextView
    private lateinit var btnToggle: Button
    private lateinit var btnClearHistory: Button
    private lateinit var listHistory: ListView
    private lateinit var txtHistoryCount: TextView

    private val sensorHistory = mutableListOf<SensorData>()
    private lateinit var historyAdapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sensores)

        setupUI()
        setupSensors()
        setupHistory()
    }

    private fun setupUI() {
        txtX = findViewById(R.id.txtX)
        txtY = findViewById(R.id.txtY)
        txtZ = findViewById(R.id.txtZ)
        txtLight = findViewById(R.id.txtLight)
        txtStatus = findViewById(R.id.txtSensorStatus)
        btnToggle = findViewById(R.id.btnToggle)
        btnClearHistory = findViewById(R.id.btnClearHistory)
        listHistory = findViewById(R.id.listHistory)
        txtHistoryCount = findViewById(R.id.txtHistoryCount)

        btnToggle.setOnClickListener {
            toggleMonitoring()
        }

        btnClearHistory.setOnClickListener {
            clearHistory()
        }
    }

    private fun setupSensors() {
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)

        var availableSensors = 0
        if (accelerometer != null) availableSensors++
        if (lightSensor != null) availableSensors++

        txtStatus.text = "✅ $availableSensors sensores disponibles"

        if (accelerometer == null) {
            txtX.text = "X: No disponible"
            txtY.text = "Y: No disponible"
            txtZ.text = "Z: No disponible"
        }

        if (lightSensor == null) {
            txtLight.text = "Luz: Sensor no disponible"
        }
    }

    private fun setupHistory() {
        historyAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList())
        listHistory.adapter = historyAdapter
        updateHistoryDisplay()
    }

    private fun toggleMonitoring() {
        isMonitoring = !isMonitoring
        if (isMonitoring) {
            startSensors()
            btnToggle.text = "⏸️ Pausar"
            Toast.makeText(this, "Monitoreo iniciado", Toast.LENGTH_SHORT).show()
        } else {
            stopSensors()
            btnToggle.text = "▶️ Reanudar"
            Toast.makeText(this, "Monitoreo pausado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startSensors() {
        accelerometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        lightSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
    }

    private fun stopSensors() {
        sensorManager.unregisterListener(this)
    }

    private fun addToHistory(data: SensorData) {
        // Agregar al final (más reciente al final)
        sensorHistory.add(data)

        // Mantener solo las últimas 20 lecturas
        if (sensorHistory.size > 20) {
            sensorHistory.removeAt(0) // Eliminar la más antigua
        }

        updateHistoryDisplay()
    }

    private fun updateHistoryDisplay() {
        // Ordenar por fecha/hora (más reciente primero)
        val sortedHistory = sensorHistory.sortedByDescending { it.timestamp }

        val historyStrings = sortedHistory.map { data ->
            when (data.sensorType) {
                "Accelerometer" -> "🔄 ${data.formattedTime} - Acel: X=${"%.2f".format(data.values[0])}, Y=${"%.2f".format(data.values[1])}, Z=${"%.2f".format(data.values[2])}"
                "Light" -> "💡 ${data.formattedTime} - Luz: ${"%.1f".format(data.values[0])} lux"
                else -> "📊 ${data.formattedTime} - ${data.values.joinToString()}"
            }
        }

        historyAdapter.clear()
        historyAdapter.addAll(historyStrings)
        txtHistoryCount.text = "Historial: ${sensorHistory.size}/20 lecturas"
    }

    private fun clearHistory() {
        sensorHistory.clear()
        updateHistoryDisplay()
        Toast.makeText(this, "Historial limpiado", Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        if (isMonitoring) {
            startSensors()
        }
    }

    override fun onPause() {
        super.onPause()
        stopSensors()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (!isMonitoring) return

        event?.let {
            when (it.sensor.type) {
                Sensor.TYPE_ACCELEROMETER -> {
                    val x = it.values[0]
                    val y = it.values[1]
                    val z = it.values[2]

                    txtX.text = "X: ${"%.2f".format(x)}"
                    txtY.text = "Y: ${"%.2f".format(y)}"
                    txtZ.text = "Z: ${"%.2f".format(z)}"

                    addToHistory(SensorData("Accelerometer", floatArrayOf(x, y, z)))
                }
                Sensor.TYPE_LIGHT -> {
                    val light = it.values[0]
                    txtLight.text = "Luz: ${"%.1f".format(light)} lux"
                    addToHistory(SensorData("Light", floatArrayOf(light)))
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // No necesario
    }
}